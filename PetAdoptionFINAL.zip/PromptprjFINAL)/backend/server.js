const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { createClient } = require('@supabase/supabase-js');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Supabase connection
const supabase = createClient(
    'https://bdmkqcunoleqcwzvzkxs.supabase.co', // Replace with your Supabase URL
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkbWtxY3Vub2xlcWN3enZ6a3hzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzYyODE2NDQsImV4cCI6MjA1MTg1NzY0NH0.dC6_V5sOLE0YGyV75dsPM7rT7mc4NCBzZ4epk4Li4sA' // Replace with your Supabase anon key
);

const app = express();
app.use(cors());
app.use(bodyParser.json());

// JWT Secret Key
const JWT_SECRET = 'your_jwt_secret_key';

// Employee Login Route
app.post('/employees/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const { data: employee, error } = await supabase
            .from('employee')
            .select('*')
            .eq('email', email)
            .single();

        if (error || !employee) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        const isPasswordValid = await bcrypt.compare(password, employee.password);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        const token = jwt.sign(
            { id: employee.employeeid, email: employee.email, role: employee.role },
            JWT_SECRET,
            { expiresIn: '2h' }
        );

        res.status(200).json({ message: 'Login successful', token });
    } catch (error) {
        res.status(500).json({ error: 'An error occurred during login' });
    }
});

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(403).json({ error: 'Access denied' });

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ error: 'Invalid token' });
        req.user = user;
        next();
    });
};

// General CRUD Handlers
const createCrudEndpoints = (entity, primaryKey) => {
    app.get(`/${entity}`, async (req, res) => {
        try {
            const { data, error } = await supabase.from(entity).select('*');
            if (error) throw error;
            res.status(200).json(data);
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    });

    app.post(`/${entity}`, async (req, res) => {
        try {
            const { data, error } = await supabase.from(entity).insert([req.body]);
            if (error) throw error;
            res.status(201).json(data);
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    });

    app.put(`/${entity}/:${primaryKey}`, async (req, res) => {
        const { [primaryKey]: id } = req.params;
        try {
            const { data, error } = await supabase.from(entity).update(req.body).eq(primaryKey, id);
            if (error) throw error;
            res.status(200).json(data);
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    });

    app.delete(`/${entity}/:${primaryKey}`, async (req, res) => {
        const { [primaryKey]: id } = req.params;
   
