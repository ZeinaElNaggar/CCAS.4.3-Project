
// Base API URL

const API_BASE_URL = "http://localhost:3001";



// Fetch and display data

async function fetchData(endpoint, elementId) {

    try {

        const response = await fetch(`${API_BASE_URL}/${endpoint}`);

        if (!response.ok) throw new Error('Failed to fetch ${endpoint}: ${response.statusText}');

        

        const data = await response.json();

        const container = document.getElementById(elementId);

        container.innerHTML = "";



        if (endpoint === "animals") {

            renderAnimalCards(data, container);

        } else {

            renderTable(data, container);

        }

    } catch (error) {

        document.getElementById(elementId).innerHTML = <p style="color: red;">Error: ${error.message}</p>;

    }

}



// Render animal data as cards

function renderAnimalCards(animals, container) {

    animals.forEach(animal => {

        const card = document.createElement("div");

        card.className = "animal-card";



        const img = document.createElement("img");

        img.src = animal.photo;

        img.alt = animal.name;

        img.className = "animal-photo";



        const info = document.createElement("div");

        info.className = "animal-info";

        info.innerHTML = `

            <h3>${animal.name}</h3>

            <p><strong>Species:</strong> ${animal.species}</p>

            <p><strong>Breed:</strong> ${animal.breed}</p>

            <p><strong>Age:</strong> ${animal.age}</p>

            <p><strong>Size:</strong> ${animal.size}</p>

            <p><strong>Health Status:</strong> ${animal.healthstatus}</p>

            <p><strong>Location:</strong> ${animal.location}</p>

            <p><strong>Adoption Status:</strong> ${animal.adoptionstatus}</p>

            <button onclick="redirectToDetails('${animal.id}')">View Details</button>

        `;



        card.appendChild(img);

        card.appendChild(info);

        container.appendChild(card);

    });

}



// Redirect to animal details page

// function redirectToDetails(animalId) {

//     window.location.href = animal-details.html?animalId=${animalId};

// }



// Fetch details for a specific animal

async function fetchAnimalDetails(animalId) {

    try {

        const response = await fetch(`${API_BASE_URL}/animals/${animalId}`);

        if (!response.ok) throw new Error('Failed to fetch animal details: ${response.statusText}');

        

        const animal = await response.json();

        const container = document.getElementById("animal-details-container");

        container.innerHTML = `

            <img src="${animal.photo}" alt="${animal.name}" class="animal-photo">

            <h2>${animal.name}</h2>

            <p><strong>Species:</strong> ${animal.species}</p>

            <p><strong>Breed:</strong> ${animal.breed}</p>

            <p><strong>Age:</strong> ${animal.age}</p>

            <p><strong>Size:</strong> ${animal.size}</p>

            <p><strong>Health Status:</strong> ${animal.healthstatus}</p>

            <p><strong>Location:</strong> ${animal.location}</p>

            <p><strong>Adoption Status:</strong> ${animal.adoptionstatus}</p>

        `;

    } catch (error) {

        document.getElementById("animal-details-container").innerHTML = <p style="color: red;">Error: ${error.message}</p>;

    }

}



// Handle adoption form submission

async function submitAdoptionForm(event) {

    event.preventDefault();



    const formData = new FormData(event.target);

    const data = Object.fromEntries(formData.entries());



    try {

        const response = await fetch(`${API_BASE_URL}/adoptionapplications`, {

            method: "POST",

            headers: { "Content-Type": "application/json" },

            body: JSON.stringify(data)

        });

        

        if (!response.ok) throw new Error(`Failed to submit application: ${response.statusText}`);

        

        alert("Application submitted successfully!");

        window.location.href = "animals.html";

    } catch (error) {

        alert(`${error.message}`);

    }

}



// Attach event listeners

document.addEventListener("DOMContentLoaded", () => {

    const urlParams = new URLSearchParams(window.location.search);

    const animalId = urlParams.get("animalId");



    if (animalId) fetchAnimalDetails(animalId);



    const adoptionForm = document.getElementById("adoption-form");

    if (adoptionForm) adoptionForm.addEventListener("submit", submitAdoptionForm);



    if (document.getElementById("animals")) fetchData("animals", "animals");

});



// Function to get query parameters

function getQueryParam(param) {

    const urlParams = new URLSearchParams(window.location.search);

    return urlParams.get(param);

}



// Function to fetch animal details by ID

async function fetchAnimalDetails(animalId) {

    try {

        const response = await fetch(`${API_BASE_URL}/animals/${animalId}`);

        if (!response.ok) throw new Error("Failed to fetch animal details");



        const animal = await response.json();

        document.getElementById("animal-photo").src = animal.photo || "placeholder.jpg";

        document.getElementById("animal-name").textContent = animal.name;

        document.getElementById("animal-species").textContent = animal.species;

        document.getElementById("animal-breed").textContent = animal.breed;

        document.getElementById("animal-age").textContent = animal.age;

        document.getElementById("animal-size").textContent = animal.size;

        document.getElementById("animal-healthstatus").textContent = animal.healthstatus;

        document.getElementById("animal-location").textContent = animal.location;

        document.getElementById("animal-adoptionstatus").textContent = animal.adoptionstatus;

    } catch (error) {

        console.error("Error fetching animal details:", error);

        alert("Error fetching animal details. Please try again later.");

    }

}



// Get the animal ID from the URL and fetch the details

const animalId = getQueryParam("animalid");

if (animalId) {

    fetchAnimalDetails(animalId);

} else {

    alert("No animal ID provided. Redirecting to the gallery...");

    window.location.href = "animals.html";

}
script.js
Displaying script.js.